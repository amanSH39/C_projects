#include <stdio.h>
#include <conio.h>
int main()
{    int a;
    printf("enter the year %d \n");
    scanf("%d", &a);
    if (a %4 == 0)
    {
        printf("yes");
    }
    else 
        printf("NO");


}